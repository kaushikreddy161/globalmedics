export const SidebarData = [
  // {
  //   title: 'Virtual Round',
  //   path: '/virtualround',
  //   cName: 'nav-text'
  // },
  {
    title: 'Virtual Round',
    path: '/virtualround',
    cName: 'nav-text'
  },
  {
    title: 'Patients Overview',
    path: '/patients',
    cName: 'nav-text'
  },
  {
    title: 'Trends',
    path: '/trends',
    cName: 'nav-text'
  },
  // {
  //   title: 'Power Bi Reports',
  //   path: '/powerBIReports',
  //   cName: 'nav-text'
  // },
  
  // {
  //   title: 'Care Plan',
  //   path: '/careplan',
  //   cName: 'nav-text'
  // },
  // {
  //   title: 'PREMS Data',
  //   path: '/premsdata',
  //   cName: 'nav-text'
  // },
  // {
  //   title: 'Mental Health',
  //   path: '/mentalhealth',
  //   cName: 'nav-text'
  // },
  // {
  //   title: 'PROMS Data',
  //   path: '/promsdata',
  //   cName: 'nav-text'
  // },
  // {
  //   title: 'Messages',
  //   path: '/messages',
  //   cName: 'nav-text'
  // },
  // {
  //   title: 'Medical History',
  //   path: '/medicalhistory',
  //   cName: 'nav-text'
  // },
  // {
  //   title: 'Diary',
  //   path: '/diary',
  //   cName: 'nav-text'
  // }

];