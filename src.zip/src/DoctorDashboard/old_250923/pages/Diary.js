import React from 'react'

function Diary() {
    return (
        <div>
            <h1>This is for notes 1233444323223</h1>
        </div>
    )
}

export default Diary
