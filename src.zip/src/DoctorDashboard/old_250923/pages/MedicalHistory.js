import React from 'react'

function MedicalHistory() {
    return (
        <div>
            <h1>this is for patients medical history</h1>
        </div>
    )
}

export default MedicalHistory
