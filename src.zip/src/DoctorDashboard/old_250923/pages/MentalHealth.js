import React from 'react'

function MentalHealth() {
    return (
        <div>
            <h1>This is for Patients health </h1>
        </div>
    )
}

export default MentalHealth
