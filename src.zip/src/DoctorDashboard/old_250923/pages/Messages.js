import React from 'react'

function Messages() {
    return (
        <div>
            <h1>This is for Messages </h1>
        </div>
    )
}

export default Messages
