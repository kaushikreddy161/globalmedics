import React from 'react'

function PremsData() {
    return (
        <div>
            <h1>This is for Prems data</h1>
        </div>
    )
}

export default PremsData
