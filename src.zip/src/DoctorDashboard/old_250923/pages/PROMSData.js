import React from 'react'

function PromsData() {
    return (
        <div>
            <h1>This is for PromsData</h1>
        </div>
    )
}

export default PromsData
