import PatientDetailSchema from './PatientDetailSchema';

export {
    PatientDetailSchema
};