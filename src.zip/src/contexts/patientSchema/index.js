import PatientSchema from './PatientSchema';

export {
    PatientSchema
};