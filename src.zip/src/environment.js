const env =  {
    dbName: 'ac-mongodbcosmos',
    key: '4aTb03qAb72r65TeIYEwvEKgq2h4lm367ELSZ66qJfq8lhQKpZREjsdIdyw68IK5A64Yr6pvvl9QtfE0jT4RDw==',
    port: 10255
}

module.exports = env;