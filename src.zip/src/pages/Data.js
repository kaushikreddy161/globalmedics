export const contactList = [
    {
      id: 1,
      name: "Anubhav Sharma",
      profilePic: "../assets/pp1.png",
      lastText: "Hey Man",
      lastTextTime: "12:58 PM",
    },
    {
      id: 2,
      name: "Mayank",
      profilePic: "../assets/pp2.png",
      lastText: `what going on bro`,
      lastTextTime: "12:45 PM",
    },
    {
      id: 3,
      name: "Anjali",
      profilePic: "../assets/pp3.png",
      lastText: "baba lets go out?",
      lastTextTime: "12:30 PM",
    },
    {
      id: 4,
      name: "Kaushal",
      profilePic: "../assets/pp4.jpeg",
      lastText: "no broo",
      lastTextTime: "12:00 PM",
    },
  ];
  export const messagesList = [
    {
      id: 1,
      messageType: "TEXT",
      text: "hello",
      senderID: 0,
      addedOn: "12:00 PM",
    },
    {
      id: 2,
      messageType: "TEXT",
      text: "What's up?",
      senderID: 1,
      addedOn: "12:01 PM",
    },
    {
      id: 3,
      messageType: "TEXT",
      text: "All Good, What about you?",
      senderID: 0,
      addedOn: "12:00 PM",
    },
    {
      id: 4,
      messageType: "TEXT",
      text: "I'm good as well",
      senderID: 1,
      addedOn: "12:00 PM",
    },
    {
      id: 5,
      messageType: "TEXT",
      text: "Great 😁",
      senderID: 0,
      addedOn: "12:00 PM",
    },
    {
      id: 5,
      messageType: "TEXT",
      text: "Subscribed to GlobalMedics",
      senderID: 1,
      addedOn: "12:00 PM",
    },
  ];
  