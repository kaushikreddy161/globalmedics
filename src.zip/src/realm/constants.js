export const APP_ID = "globalmedics-yxogc";
export const GRAPHQL_ENDPOINT = "https://us-east-1.aws.realm.mongodb.com/api/client/v2.0/app/globalmedics-yxogc/graphql";